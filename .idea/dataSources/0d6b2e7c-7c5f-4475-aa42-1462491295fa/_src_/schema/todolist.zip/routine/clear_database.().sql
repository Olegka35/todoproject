CREATE PROCEDURE `clear_database`()
  BEGIN
	DROP TABLE `subtasks`;	
    DROP TABLE `tasks`;
	DROP TABLE `users`;
END