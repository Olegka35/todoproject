CREATE PROCEDURE `create_database`()
  BEGIN
	CREATE TABLE `users` (
	  `ID` int(11) NOT NULL AUTO_INCREMENT,
	  `Login` varchar(45) DEFAULT NULL,
	  `password` varchar(45) DEFAULT NULL,
	  PRIMARY KEY (`ID`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	CREATE TABLE `tasks` (
	  `ID` int(11) NOT NULL AUTO_INCREMENT,
	  `user` int(11) DEFAULT NULL,
	  `name` varchar(45) DEFAULT NULL,
	  `description` varchar(140) DEFAULT NULL,
	  PRIMARY KEY (`ID`),
	  KEY `owner_idx` (`user`),
	  CONSTRAINT `owner` FOREIGN KEY (`user`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	CREATE TABLE `subtasks` (
	  `ID` int(11) NOT NULL,
	  `user` int(11) DEFAULT NULL,
	  `parent` int(11) DEFAULT NULL,
	  `name` varchar(45) DEFAULT NULL,
	  `description` text,
	  `subtaskscol` varchar(45) DEFAULT NULL,
	  PRIMARY KEY (`ID`),
	  KEY `parentTask_idx` (`parent`),
	  KEY `owner_idx` (`user`),
	  CONSTRAINT `parentTask` FOREIGN KEY (`parent`) REFERENCES `tasks` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
	  CONSTRAINT `subtaskOwner` FOREIGN KEY (`user`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;

END